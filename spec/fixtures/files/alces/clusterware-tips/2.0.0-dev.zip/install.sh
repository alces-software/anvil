#!/bin/bash

cp -pR data/* "${cw_ROOT}"
